jQuery(document).ready(function(){ 

	 


	 // DropDown Menu 
    jQuery('.dropdown_menu a').click(function () {
        jQuery('.dropdown-content').slideToggle(800);
         return false;
    });
     // DropDown Menu 2
    jQuery('.dropdown_menu2 a').click(function () {
        jQuery('.dropdown-content2').slideToggle(800);
         return false;
    });
      // DropDown Menu 3
    jQuery('.dropdown_menu3 a').click(function () {
        jQuery('.dropdown-content3').slideToggle(800);
         return false;
    });

		
		
	

});